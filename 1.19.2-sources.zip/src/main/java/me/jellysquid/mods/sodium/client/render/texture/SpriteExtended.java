package me.jellysquid.mods.sodium.client.render.texture;

public interface SpriteExtended {
    void setActive(boolean b);

    boolean isActive();
}
