package me.jellysquid.mods.sodium.client.gl.util;

public record ElementRange(int elementPointer, int elementCount) {
}
