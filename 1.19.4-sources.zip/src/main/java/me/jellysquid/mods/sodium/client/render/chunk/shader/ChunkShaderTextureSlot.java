package me.jellysquid.mods.sodium.client.render.chunk.shader;

public enum ChunkShaderTextureSlot {
    BLOCK,
    LIGHT;

    public static final ChunkShaderTextureSlot[] VALUES = ChunkShaderTextureSlot.values();
}
