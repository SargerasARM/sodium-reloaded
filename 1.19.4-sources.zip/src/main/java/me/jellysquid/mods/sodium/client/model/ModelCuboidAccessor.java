package me.jellysquid.mods.sodium.client.model;

import me.jellysquid.mods.sodium.client.render.immediate.model.ModelCuboid;

public interface ModelCuboidAccessor {
    ModelCuboid copy();
}
