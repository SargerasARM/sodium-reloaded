Sodium Reloaded IS NOT associated directly with Sodium or its authors.
It is a fork of https://github.com/CaffeineMC/sodium-fabric.