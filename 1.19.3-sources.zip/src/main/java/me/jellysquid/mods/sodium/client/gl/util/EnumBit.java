package me.jellysquid.mods.sodium.client.gl.util;

public interface EnumBit {
    int getBits();
}
