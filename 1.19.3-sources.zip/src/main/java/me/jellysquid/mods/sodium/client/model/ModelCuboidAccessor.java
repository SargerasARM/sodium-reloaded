package me.jellysquid.mods.sodium.client.model;

import net.minecraft.client.model.ModelPart;

public interface ModelCuboidAccessor {
    ModelPart.Quad[] getQuads();
}
